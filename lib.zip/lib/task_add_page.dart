import 'package:flutter/cupertino.dart';

class TaskAddPage extends StatelessWidget {
  const TaskAddPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
